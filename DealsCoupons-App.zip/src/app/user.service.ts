import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable} from 'rxjs';
import { doctorinfo } from './doctorlist';
import { catchError } from 'rxjs/internal/operators/catchError';
import { packageDetails } from './Package';


@Injectable({
  providedIn: 'root'
})
export class UserServiceService {
headers= new HttpHeaders({'Access-Control-Allow-Origin': '*'})


private docurl="http://localhost:8050/docinfo";

private customerurl="http://localhost:8051/customer";

private patientdataurl="http://localhost:8052/patient";

private packageurl="http://localhost:8055/package";

private paymenturl="http://localhost:8056";



  constructor( private http:HttpClient) { }

createCustomer(Customer):Observable<any>{
  return this.http.post(`${this.customerurl}/register`, Customer);
  //.pipe(catchError(this.errorHandler));
}


loginDetails(loginCustomer){
  return this.http.post(`${this.customerurl}/signin`, loginCustomer);
}

GetAllCustomers():Observable<any>{
  return this.http.get(`${this.customerurl}/allcustomer`);
}

totalCustomersCount():Observable<any>{
  return this.http.get(`${this.customerurl}/totalCustomercount`);
}

// ***********************************************************************************************************************************
//Doctors urls and services

AddDoctor(doctorinfo):Observable<any>{
  return this.http.post(`${this.docurl}/adddoctor`,doctorinfo);
}

GetAllDoctors():Observable<any>{
  return this.http.get(`${this.docurl}/alldoctors`);
  //.pipe(catchError(this.errorHandler));
}

//check this method
UpdateDoctorInfo(doctorinfo:any):Observable<any>{
  return this.http.put(`${this.docurl}/docinfoupdate/${name}`, name,doctorinfo);
}

DeleteDocById(doctorid:String):Observable<any>{
  return this.http.delete<doctorinfo>(`${this.docurl}/removebyId/${doctorid}`);
}

totalDocCount():Observable<any>{
  return this.http.get(`${this.docurl}/totalDoctorcount`);
}

SearchDocBySpeciality(specialisation:String):Observable<any>{
  return this.http.get(`${this.docurl}/getDocBySpeciality/${specialisation}`);
}

//***********************************************************************************************************************************

//patient urls and services
savePatientData(patientdata:any):Observable<any>{
  return this.http.post(`${this.patientdataurl}/savedata`, patientdata);
}


//***********************************************************************************************************************************

//package Details
GetAllOffers():Observable<any>{
  return this.http.get(`${this.packageurl}/getAllPackages`);
}

AddnewPackage(Package):Observable<any>{
  return this.http.post(`${this.packageurl}/addnewpackage`, Package);
}

totalPackageCount():Observable<any>{
  return this.http.get(`${this.packageurl}/totalPackagecount`);
}

deletePackageById(packageId:String):void{
   this.http.delete<packageDetails>(`${this.docurl}/removepack/${packageId}`);
}

//************************************************** */
//PaymentDetails
AddNewPayment(Payment):Observable<any>{
   return this.http.post(`${this.paymenturl}/payment`, Payment);
 }

 FindPaymentsByEmail(email:String):Observable<any>{
   return this.http.get(`${this.paymenturl}/mypayments/${email}`)
 }

 findallPayments():Observable<any>{
   return this.http.get(`${this.paymenturl}/allpayments`);
 }

 ///*/******************************************************************************** */
isUserLoggedIn(){
  return localStorage.getItem("email");
}

}

//*************************************************************************************************************************

//other details
// createUser(user: any): Observable<any>{
//   return this.http.post(`${this.baseurl}/register`, user);
// }

// getUserByEmail(emailid:String):Observable<any>{
//   return this.http.get(`${this.baseurl}/${emailid}`);
// }

// getAllUsers():Observable<any>{
//   return this.http.get(`${this.baseurl}/allUsers`);
// }

// getUserByid(userid:String): Observable<any>{
//   return this.http.get(`${this.baseurl}/${userid}`)
// }

// //To delete User
// deleteUserByEmail(emailid:String):Observable<any>{
//   return this.http.delete(`${this.baseurl}/${emailid}`);
// }

// getAllproducts(): Observable<any>{
//   return this.http.get(`${this.producturl}/allHotels`);
// }
