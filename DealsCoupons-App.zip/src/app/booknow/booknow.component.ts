import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserServiceService } from '../user.service';
import { PatientData } from '../PatientData';
import { error } from 'protractor';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { first } from 'rxjs/operators';
/* Bootstrap css */
/* Google Material icons */
/* Propeller css */
/* Bootstrap datetimepicker */
/* Propeller datetimepicker */


@Component({
  selector: 'app-booknow',
  templateUrl: './booknow.component.html',
  styleUrls: ['./booknow.component.css']
})
export class BooknowComponent implements OnInit {

  //model: any={};
submitted=false;
loading=false;
regPatient:FormGroup;
error:String;

  model:PatientData = new PatientData();
  constructor(private router:Router, private patientService:UserServiceService, private formBuilder:FormBuilder) { }

  ngOnInit() {
    this.regPatient= this.formBuilder.group({
      fullname:['', Validators.required],
      gender:['',Validators.required],
      mobilenum:['',Validators.required],
      age:['',Validators.required, Validators.max],
      email:['',Validators.required],
      schedule:['', Validators.required],
      scheduletime:['', Validators.required]

    })

  }

  get f(){
    return this.regPatient.controls;
  }

   //button functionalities
   onPayment(){
    this.router.navigateByUrl('payment');
  }

 onCancel(){
  this.router.navigateByUrl('home');
 }

  onSubmit(){
   this.submitted= true;
   if(this.regPatient.invalid){
    alert("Fields are Mandatory!");
  }

  this.loading=true;
  this.patientService.savePatientData(this.regPatient.value).pipe(first())
  .subscribe(data =>{
    console.log("working!"+data);
    this.router.navigateByUrl(('payment'), { queryParams: { registered:true}});
  },
  error=>{
    alert("error occured!");
    this.error=error;
    this.loading=false;
    
  })

  // let pdata:PatientData={
  //   fullName:form.value.fullName,
  //   gender:form.value.gender,
  //   phoneNumber:form.value.phoneNumber,
  //   dob:form.value.dob,
  //   emailId:form.value.emailId,
  //   lastpresence:form.value.lastpresence,
  //   presenceDetails:form.value.presenceDetails,
  //   scheduleDate:form.value.scheduleDatetime,
  //   scheduleTime:form.value.scheduleTime
  // }
  // console.log("patient data: ", pdata)
  // this.patientService.savePatientData(pdata).subscribe(data=>{
  //   if(data){
  //     console.log("its working");
  //     this.router.navigateByUrl('payment');
  //   }
  //   else{
  //     alert("Error Ocurred");
  //     console.log("Not Working");
  //   }
  // })
};
 
}
