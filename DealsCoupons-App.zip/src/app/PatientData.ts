import { Time } from '@angular/common';

export class PatientData{

    fullName:String;
    gender:String;
    mobilenum:number;
    age:number;
    email:String;
    lastpresence:boolean;
    presenceDetails:String;
    schedule:Date;
    scheduleTime:String;
    
}