import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-buynow',
  templateUrl: './buynow.component.html',
  styleUrls: ['./buynow.component.css']
})
export class BuynowComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  placeorder(){
    alert("Your Order is Placed Successfully");
  }
}
