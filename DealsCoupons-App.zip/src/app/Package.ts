export class packageDetails{
    packageId?:String;
    name: String;
    sampleType:String;
    fastingRequired:boolean;
    OriginalPrice:number;
    discountPrice:number;
    finalPrice:number;
}