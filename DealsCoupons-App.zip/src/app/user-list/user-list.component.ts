// import { Component, OnInit } from '@angular/core';
// import { UserServiceService } from '../user.service';
// import { error } from 'protractor';
// import { Observable } from 'rxjs';

// @Component({
//   selector: 'app-user-list',
//   templateUrl: './user-list.component.html',
//   styleUrls: ['./user-list.component.css']
// })
// export class UserListComponent implements OnInit {

//   user: Observable<any>;

//   constructor( private userservice:UserServiceService) { }

// //   ngOnInit() {
// //     this.reloadData();
// //   }

// //   getCustomers(){
// //     this.userservice.getAllUsers().subscribe(data =>{
// //       console.log(data);
// //       this.reloadData();
// //     },
// //     error => console.log('ERROR: ' + error));
// //   }

// //   reloadData() {
// //     this.user = this.userservice.getAllUsers();
// //   }

// // 
// }
