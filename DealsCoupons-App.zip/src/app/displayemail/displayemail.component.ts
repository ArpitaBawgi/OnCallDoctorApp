import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-displayemail',
  templateUrl: './displayemail.component.html',
  styleUrls: ['./displayemail.component.css']
})
export class DisplayemailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  displayvalue = localStorage.getItem("email");
  user=localStorage.getItem("name");
}
