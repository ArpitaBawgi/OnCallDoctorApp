import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Iplayer } from './player';

import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';




@Injectable({
  providedIn: 'root'
})
export class PlayerService {

private _url: string = "/assets/data/player1.json";

  constructor(private http:HttpClient) { }

  getPlayers(): Observable<Iplayer[]>{
    return this.http.get<Iplayer[]>(this._url).pipe(catchError(this.errorHandler));
                
  }

  errorHandler(error: HttpErrorResponse){
    return throwError(error.message || "Server Error");
  }

  getPlayersSimple(){
    return [{"id":1, "name":"A", "age":25},
    {"id":2, "name":"B", "age":26}]
  }
}
