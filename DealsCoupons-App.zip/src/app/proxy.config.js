// {
//     "/api/*":{
//         "target":"http://localhost:8085",
//         "secure":false,
//         "changeOrigin":true,
//         "loglevel":"debug"
//     }
// }

// 'use strict';

// const proxyConfig = [{
//     context: '/user/', //here also
//     target: ' http://localhost:8085/', //here you need to chng http://iot.digitalcloudplatform.com:8080/SAVEFILTER
//     changeOrigin: true,
//     secure: false,
// }
// {
//     context: '/api/pay/checkout/',
//     target: 'http://localhost:8882/',
//     changeOrigin: false,
//     secure: false,
// }
//];


// module.exports=proxyConfig;