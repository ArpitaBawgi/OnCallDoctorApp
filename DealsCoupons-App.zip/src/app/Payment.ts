export class Payment{
        email?:string;
        cvv:Number;
        cardNumber:Number;
        cardHolderName:String;
        cardExpiryMonth:String;
        cardExpiryYear:number;
    
}