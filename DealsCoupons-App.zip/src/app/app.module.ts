import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule, routingComponents } from './app-routing.module';
import { AppComponent } from './app.component';
import { CouponsComponent } from './coupons/coupons.component';
import { AboutUsComponent } from './about-us/about-us.component';

import { HomeComponent } from './home/home.component';

import { PlayerService } from './player.service';
import { HttpClientModule } from '@angular/common/http';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';

import { ReactiveFormsModule } from '@angular/forms';

import { RegistrationComponent } from './registration/registration.component';

import { FormsModule } from '@angular/forms';
import { UserServiceService } from './user.service';
import { LoginComponent } from './login/login.component';
import { BuynowComponent } from './buynow/buynow.component';
import { BooknowComponent } from './booknow/booknow.component';
import { PaymentComponent } from './payment/payment.component';
import { AdminComponent } from './admin/admin.component';
import { LogoutComponent } from './logout/logout.component';

import { AuthGuardService } from './auth-guard.service'
import { AuthenticationService } from './authentication.service';
import { DisplayemailComponent } from './displayemail/displayemail.component';


@NgModule({
  declarations: [
    AppComponent,
    routingComponents,
    
    HomeComponent,
    HeaderComponent,
    FooterComponent,
    RegistrationComponent,
    LoginComponent,
    BuynowComponent,
    BooknowComponent,
    PaymentComponent,
    AdminComponent,
    LogoutComponent,
    DisplayemailComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    ReactiveFormsModule,
    FormsModule
  ],
  providers: [PlayerService, UserServiceService, AuthGuardService, AuthenticationService],
  bootstrap: [AppComponent]
})
export class AppModule { }
