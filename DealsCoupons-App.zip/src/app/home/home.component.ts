import { Component, OnInit } from '@angular/core';
import { PlayerService } from '../player.service';
import { error } from 'protractor';
import { UserServiceService } from '../user.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {


  public doctorlist=[];
  public players=[];
 public playersa=[];

 public doctordata=[];

 public errorMsg;

  public playersp= [
    {"id":1, "name":"Aru", "age":25},
    {"id":2, "name":"Banu", "age":26},
    {"id":3, "name":"Coci", "age":27},
    {"id":4, "name":"Dona", "age":28},
    {"id":5, "name":"Emma", "age":29},
  ]

email=localStorage.getItem("email");

  constructor(private playerService: PlayerService, private userservice:UserServiceService) { }

  ngOnInit() {
    
    this.playersa= this.playerService.getPlayersSimple();

    //for service oriented
    this.playerService.getPlayers().subscribe( data => this.players = data,
                                               error => this.errorMsg =error);


    this.userservice.GetAllDoctors().subscribe(data=> this.doctorlist = data,
                                                   error => this.errorMsg= error);
    
  }

  onSelect(specialisation:String){
     this.userservice.SearchDocBySpeciality(specialisation).subscribe(data=>this.doctorlist=data,
      error=>this.errorMsg=error);
  }
}
