export interface Iplayer{
    id:number,
    name:string,
    age:number
}