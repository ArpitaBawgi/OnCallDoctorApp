import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { Payment } from '../Payment';
import { UserServiceService } from '../user.service';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css']
})
export class PaymentComponent implements OnInit {

  paymentForm:FormGroup;
  addPayment:Payment;
  submitted=false;

  constructor(private router:Router, private formBuilder: FormBuilder, private paymentService:UserServiceService) { }

  ngOnInit() {
    this.paymentForm= new FormGroup({
      cvv: new FormControl('',[Validators.required,Validators.minLength(3),Validators.maxLength(3)]),
      cardNumber: new FormControl('',[Validators.required,Validators.minLength(12),Validators.maxLength(12)]),
      cardHolderName:new FormControl('',Validators.required),
      cardExpiryMonth:new FormControl('',Validators.required),
      cardExpiryYear:new FormControl('',[Validators.required,Validators.maxLength(4)])

    });
  }

  onCOD(){
    alert("Available only for Doctor Consultation");
  }
  onCheckout(){
    alert(" Payment Done & Appointment Scheduled successfully!");
    this.router.navigateByUrl('home');

  }


  get f(){
    return this.paymentForm.controls;
  }



  onSubmit(){
    this.submitted=true;

    if(this.paymentForm.invalid){
      alert("All fields are mandatory, Please fill all of them Correctly!");
    }
    // else{
    // let makepayment:Payment={
    //   cvv:form.value.cvv,
    //   cardNumber: form.value.cardNumber,
    //   cardHolderName: form.value.cardHolderName,
    //   cardExpiryMonth: form.value.cardExpiryMonth,
    //   cardExpiryYear:form.value.cardExpiryYear

    // }
    // console.log("PaymentDetails: ",makepayment)
      this.paymentService.AddNewPayment(this.paymentForm).subscribe(data=>{
        if(data){
          console.log(data);
          alert("Payment Done Successfully!");
          this.router.navigateByUrl('home');
        }
        else{
          alert("Error Occured while processing payment please try again!");
        }
      })

    }
  }

