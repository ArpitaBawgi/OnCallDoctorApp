import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  headers= new HttpHeaders({'Access-Control-Allow-Origin': '*'})
  
  private baseurl="http://localhost:8091";

  constructor(private http:HttpClient) { }

  getImage(id:String):Observable<any>{
    return this.http.get(`${this.baseurl}/image/${id}`)
  }

  getAllImages():Observable<any>{
    return this.http.get(`${this.baseurl}/images`);
  }
  
}
