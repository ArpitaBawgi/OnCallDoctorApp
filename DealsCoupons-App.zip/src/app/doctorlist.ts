export class doctorinfo{
    doctorid?:String;
    name:String;
    specialisation:String;
    teleConsultAvailable:boolean;
    consultationfee:Number;
    teleConsultfee:Number;
    clinicAddress:String;
    qualification:String;

}