import { Injectable } from '@angular/core';
// import { AngularFireAuth } from "@angular/fire/auth";
import { Router } from '@angular/router';
import { User } from './user';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  constructor(  //inject firebaseauth
    public router: Router  ) {
      /**saving user data as a obj in localstorage */
     // this.afAuth.authState.subscribe(User)
      
     }

  // authenticate(emailid,password){
  //   if(emailid==="admin@gmail.com" && password==="admin"){
  //     sessionStorage.setItem('emailid',emailid)
  //     return true;
  //   }
  //   else{
  //     return false;
  //   }
  // }

  // isUserLoggedIn(){
  //   let user=sessionStorage.getItem('emailid')
  //   console.log(!(user===null))
  //   return !(user===null)
  // }
  
  // logout(){
  //   sessionStorage.removeItem('email');
  // }
}
