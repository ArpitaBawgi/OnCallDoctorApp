import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from '../user';
import { EmailValidator, NgModel, Form } from '@angular/forms';
import { HttpHeaders } from '@angular/common/http';
import { UserServiceService } from '../user.service';
import { error } from 'protractor';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  providers: [UserServiceService]
})
export class LoginComponent implements OnInit {

 // headers= new HttpHeaders({'Access-Control-Allow-Origin': '*'})
  
  constructor(private router:Router, private userService:UserServiceService) { }

  ngOnInit() {
  }
  user: User = {
    userid:'',
    fname:'',
    lname:'',
    mobilenumber:12,
    email:'',
    password:'',
  };

  isUserLoggedIn(){}
}
  // loginUser(form){
  //   let user1: User={
  //     emailid: form.value.emailid,
  //     password: form.value.password
  //   }
  //   console.log("Login user data", user1)
  //   this.userService.loginDetails(emailid,password).subscribe(
  //     data => {
  //       console.log(data);
  //     })
  // }

  // check(){
  //      this.userService.loginDetails(this.user.emailid, this.user.password).subscribe(
  //        data=> {
  //          console.log(data);
  //        },
  //        error => console.log(error));
  //  }

  //  OnSubmit(){
  //    this.check();
  //    this.router.navigateByUrl('home');
  //  }

  // OnCancel(){
  // this.router.navigateByUrl("register");
  // }

