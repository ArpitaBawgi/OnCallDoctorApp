export class loginCustomer{
    email:string;
    password:string;
}