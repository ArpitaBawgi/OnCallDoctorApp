import { Component, OnInit } from '@angular/core';
import { Customer } from '../RegisterCustomer';
import { UserServiceService } from '../user.service';
import { Router } from '@angular/router';
import { error } from 'protractor';
import { AuthenticationService } from '../authentication.service';
import { loginCustomer } from '../LoginCustomer';
import { BehaviorSubject } from 'rxjs';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  private loggedIn: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
  
  constructor(private custService:UserServiceService, private router:Router ) {
    if(localStorage.getItem("email")!=null){
    this.loggedIn.next(true)}
   }

  ngOnInit() {
  }
  //customerlist: Customer[]=[];
  customer: Customer ={
    fname:'',
    lname:'',
    mobilenumber:12,
    email:'',
    password:'',
  }

  OnSubmit(form){

    let logincustomer: loginCustomer={
      email: form.value.email,
      password:form.value.password
    } 
    console.log("login CustomerData", logincustomer)

    if(form.value.email=="admin@gmail.com" && form.value.password=="admin"){
             localStorage.setItem("email",form.value.email);
                  this.router.navigateByUrl('admin');
                  alert("Successfully logged in as Admin!");
                
    }else{
    this.custService.loginDetails(logincustomer).subscribe(data=> {
      if(data){
        console.log("its working" + data);
        localStorage.setItem("email",logincustomer.email);
        this.router.navigateByUrl('home');
        alert("Successfully Logged with Email: "+logincustomer.email);
      }
      else{
        alert("Details are incorrect");
        console.log("not working" );
      }
    });
  }
}

isUserLoggedIn(){
    let user=localStorage.getItem('email')
    console.log(!(user===null))
    return !(user===null)
  }

onCancel(){
  this.router.navigateByUrl('register');
}



logout(){
  localStorage.removeItem("email");
  alert("You are Successfully logged out!")
   this.router.navigateByUrl('register');
 }

 }

//trial thing
// emailid="admin1@gmail.com";
// password="admin";
// invalidLogin=false;

// checkLogin(){
//   if(this.loginauthservice.authenticate(this.emailid, this.password)){
//     this.router.navigateByUrl('admin');
//     this.invalidLogin=false;
//   }
//   else{
//     this.invalidLogin=true;
//   }
// }
// login(){
//   this.custService.loginDetails(this.credentials.email,this.credentials.password, ()=> {
//     this.router.navigateByUrl('home');
//   }).subscribe(
//     data =>{
//       console.log(data);
//     },
//     error => console.log(error));
// }

// OnSubmit(){
//   this.login();
//    this.router.navigateByUrl('home');
// }


