import { Component, OnInit } from '@angular/core';
import { UserServiceService } from '../user.service';
import { Router } from '@angular/router';
import { error } from 'protractor';
import { doctorinfo } from '../doctorlist';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { packageDetails } from '../Package';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
 
 public errorMsg: any;

  constructor(private router:Router, private service:UserServiceService, private formBuilder:FormBuilder) { }

  public customerlist=[];

  public doctorlist=[];

  public packagelist=[];

  submitted=false;
  addDoctor:doctorinfo;

  addPackage:packageDetails;
//formgroupname
  AddDoctorForm:FormGroup;
  AddPackageForm:FormGroup;


  ngOnInit() {
    
    this.AddDoctorForm=this.formBuilder.group({
      name:['', Validators.required],
      qualification:['',Validators.required],
      availablility:['',Validators.required],
      specialisation:['',Validators.required],
      consultationfee:['',Validators.required],
      teleConsultfee:['',Validators.required],
      clinicAddress:['',Validators.required]

    });

    this.AddPackageForm=this.formBuilder.group({
      packagename:['',Validators.required],
      sampletype:['',Validators.required],
      fastrequired:['', Validators.required],
      originalprice:['',Validators.required],
      discount:['',Validators.required],
      final:['',Validators.required]

    });

    this.service.GetAllCustomers().subscribe(data=> this.customerlist = data,
      error => this.errorMsg= error);

      this.service.GetAllDoctors().subscribe(data=> this.doctorlist = data,
        
        error =>this.errorMsg = error);

        this.service.GetAllOffers().subscribe(data=>this.packagelist=data,
          error=>this.errorMsg= error);
}

get f(){
  return this.AddDoctorForm.controls;
}

get f1(){
  return this.AddPackageForm.controls;
}
//getdoctid(){console.log(this.addDoctor.id); return this.addDoctor.id};
mydata: any;

onDelete(doctorid:String){
  console.log(doctorid);
  if(confirm("Are you sure to delete??")){
  this.service.DeleteDocById(doctorid).subscribe(data=> this.mydata=data,
      error=> this.errorMsg = error);

      if(this.mydata){
        alert("Information"+this.mydata);
      }
  }
  
}



onDelete1(packageId:String){
  console.log(packageId);
  if(confirm("Are you sure you want to delete?")){
    this.service.deletePackageById(packageId);
  }
}

    // if(data){
    //   console.log("d"+data);
    //   alert("Deleted Successfully!");
    //   console.log("deleted");
    // }
    // else{
    //   alert("Internal Server Error!");   
    // }
// **************************************************************************************************
public docCount:any;
getTotalDocCount(){
  this.service.totalDocCount().subscribe(data=>this.docCount=data,
    error=>this.errorMsg=error);
}

public custCount:any;
getTotalCustomerCount(){
  this.service.totalCustomersCount().subscribe(data=>this.custCount=data,
    error=>this.errorMsg=error);
}

public packageCount:any;
getTotalPackageCount(){
  this.service.totalPackageCount().subscribe(data=>this.packageCount=data,
    error=>this.errorMsg=error);
}

// **************************************************************************************************

getAllCustomers(){
  this.service.GetAllCustomers().subscribe(data=> this.customerlist = data,
    error => this.errorMsg= error);

}

getAllDoctors(){
  this.service.GetAllDoctors().subscribe(data=> this.doctorlist = data,
    error =>this.errorMsg = error);
}


getAllPackageList(){
  this.service.GetAllOffers().subscribe(data=>this.packagelist = data,
    error => this.errorMsg = error);
}
//************************************************************************************** */

////saving doctordetails
OnSubmit(form){
  this.submitted=true;

  if(this.AddDoctorForm.invalid){
    alert("Error Occured!");
  }
  else{
    let regDoc:doctorinfo={
      name:form.value.name,
      qualification:form.value.qualification,
      specialisation:form.value.specialisation,
      teleConsultAvailable:form.value.availablility,
      consultationfee:form.value.consultationfee,
      teleConsultfee:form.value.teleConsultfee,
      clinicAddress:form.value.clinicAddress
    }
    console.log("AddDocDetails", regDoc)
    this.service.AddDoctor(regDoc).subscribe( data=>{
      if(data){
        console.log("its working"+ data);
        alert("Added Successfully!");
        this.router.navigateByUrl('admin');
      }
      else{
        alert("Error Occured!");
        console.log("Not Working");
      }
    })
  }
}

OnSubmitpack(form){
  this.submitted=true;

  if(this.AddPackageForm.invalid){
    alert("Error Occured!");
  }
  else{
    let regPack:packageDetails={
      name:form.value.packagename,
      sampleType:form.value.sampletype,
      fastingRequired:form.value.fastrequired,
      OriginalPrice:form.value.originalprice,
      discountPrice:form.value.discount,
      finalPrice:form.value.final
    }
    console.log("AddPackageDetails", regPack)
    this.service.AddDoctor(regPack).subscribe( data=>{
      if(data){
        console.log("its working"+ data);
        alert("Added Successfully!");
        this.router.navigateByUrl('admin');
      }
      else{
        alert("Error Occured While Adding!");
        console.log("Not Working");
      }
    })
  }

}


onLogout(){
  alert("Are you sure you want to logout?")
  this.router.navigateByUrl('register');
}
}