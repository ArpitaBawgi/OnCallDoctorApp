import { Component, OnInit } from '@angular/core';
import { UserServiceService } from '../user.service';
import { BehaviorSubject } from 'rxjs';

@Component({
  selector: 'app-displayemail',
  templateUrl: './displayemail.component.html',
  styleUrls: ['./displayemail.component.css']
})
export class DisplayemailComponent implements OnInit {

  private loggedIn: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
  
  constructor(private service:UserServiceService) {
    if(localStorage.getItem("email")!=null){
      this.loggedIn.next(true)}
   }

  ngOnInit() {
  }

  displayvalue = localStorage.getItem("email");
  user=localStorage.getItem("name");
}
