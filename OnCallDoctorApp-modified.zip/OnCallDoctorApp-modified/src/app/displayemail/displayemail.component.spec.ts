import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DisplayemailComponent } from './displayemail.component';

describe('DisplayemailComponent', () => {
  let component: DisplayemailComponent;
  let fixture: ComponentFixture<DisplayemailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DisplayemailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DisplayemailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
