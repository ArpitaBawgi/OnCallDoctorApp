import { Binary } from '@angular/compiler';

export class Product {
    Id:String;
    title:String;
    image:Binary;
    description:String;
}