import { Component, OnInit } from '@angular/core';
import { User } from 'src/app/user';
import { UserServiceService } from '../user.service';
import { error } from 'protractor';
import { Router } from '@angular/router';
import { Customer } from '../RegisterCustomer';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';


@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {

  customer: Customer;

  submitted=false;
  registerForm: FormGroup;
  form: any;
    

  constructor(private formBuilder: FormBuilder ,private userService:UserServiceService, private router:Router, private http:HttpClient) { }

  ngOnInit() {
    this.registerForm = this.formBuilder.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      mobilenumber:['',[Validators.required, Validators.minLength(10)]],
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]]
  });
  
  }

  get f(){
    return this.registerForm.controls;
  }

  get custid(){return this.customer.customer_id}

  //workonthis
  // getcustEmail(){return this.registerForm.get('email');}
  // getcustEmailfromDB(){return this.http.get}

//using login example trial
OnSubmit(form){
  this.submitted=true;

  if(this.registerForm.invalid){
        alert( "error occured!");
      }
   else{
  let regcustomer:Customer={
    fname:form.value.firstName,
    lname:form.value.lastName,
    mobilenumber:form.value.mobilenumber,
    email:form.value.email,
    password:form.value.password
  }
  console.log("RegDetails", regcustomer)
  this.userService.createCustomer(regcustomer).subscribe(data=>{
    if(data){
      console.log("its saving data" + data);
      alert("Registered Successfully!")
      this.router.navigateByUrl('home')
    }
    else{
      console.log("not working");
    }
  })
}
}



  // save(){
  //   this.userService.createCustomer(this.customer).subscribe(
  //     data => {
  //       console.log(this.customer);
  //       console.log("hitting url"+data);
  //       this.submitted= true;
  //     },
  //     error => console.log("this is not saving data"+error));
      
  // }

  // OnSubmit(){
  //   this.submitted=true;
    
  //  // this.router.navigateByUrl('home');
  // //   this.submitted=true;

  // //   //stoping here if form is invalid
  //   if(this.registerForm.invalid){
  //     return "error occured!";
  //   }
  //   else{
  //    this.save();
  //    this.router.navigateByUrl('home');
  //   }
  // }


  OnCancel(){
  this.router.navigateByUrl("login");
  }
}


// console.log(this.registerForm.value);
//     if(this.registerForm.valid){
//       alert('user form is valid');
//     }else{

//     alert("invalid!");
//   }