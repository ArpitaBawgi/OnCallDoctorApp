import { Component, OnInit, Input } from '@angular/core';
import { User } from 'src/app/user';
import { UserServiceService } from '../user.service';
import { Router } from '@angular/router';

import { Binary } from '@angular/compiler';
import { toBase64String } from '@angular/compiler/src/output/source_map';
import { error } from 'protractor';

@Component({
  selector: 'app-coupons',
  templateUrl: './coupons.component.html',
  styleUrls: ['./coupons.component.css'],
})
export class CouponsComponent implements OnInit {

  

  constructor(private packageService:UserServiceService, private router:Router) { }

  
  public packageList=[];
  public errorMsg;

  ngOnInit() {

    this.packageService.GetAllOffers().subscribe(data => this.packageList = data,
                                                  error => this.errorMsg=error);
  }




}
