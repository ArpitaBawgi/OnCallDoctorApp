import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CouponsComponent } from './coupons/coupons.component';
import { AboutUsComponent } from './about-us/about-us.component';

import { HomeComponent } from './home/home.component';
import { RegistrationComponent } from './registration/registration.component';
import { LoginComponent } from './login/login.component';
import { BuynowComponent } from './buynow/buynow.component';
import { BooknowComponent } from './booknow/booknow.component';
import { PaymentComponent } from './payment/payment.component';
import { AdminComponent } from './admin/admin.component';
import { LogoutComponent } from './logout/logout.component';
import { AuthGuardService } from './auth-guard.service';
import { FooterComponent } from './footer/footer.component';



const routes: Routes = [
  {path:'', component:RegistrationComponent},
  {path:'booknow', component:BooknowComponent, canActivate:[AuthGuardService]},
  {path:'login', component:LoginComponent},
  {path:'home', component:HomeComponent, canActivate:[AuthGuardService]},
  {path:'visitdoc', component:HomeComponent, canActivate:[AuthGuardService]},
  {path:'payment', component:PaymentComponent, canActivate:[AuthGuardService]},
  {path:'admin', component:AdminComponent, canActivate:[AuthGuardService]},
  {path:'logout', component:LogoutComponent,canActivate:[AuthGuardService]},
  {path:'coupons', component: CouponsComponent},
  {path:'aboutUs', component: AboutUsComponent},
  {path:'register', component: RegistrationComponent},
  // {path:'buynow', component:BuynowComponent},
  {path:'**', redirectTo:''} //wildroute
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

export const routingComponents =[
  CouponsComponent,
  AboutUsComponent,
  HomeComponent,
  PaymentComponent,
  RegistrationComponent,
  LoginComponent,
  BuynowComponent,
  BooknowComponent,
  AdminComponent,
  LogoutComponent
]