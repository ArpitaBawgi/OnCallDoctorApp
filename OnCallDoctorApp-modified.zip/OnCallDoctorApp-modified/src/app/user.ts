export class User{
    userid:String;
    fname:String;
    lname:String;
    mobilenumber:number;
    email:String;
    password:String;
}